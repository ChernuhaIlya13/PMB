﻿namespace PMB.Bet365.Models;

public record StakesResultModel(string FirstStakeCoef,string SecondStakeCoef);