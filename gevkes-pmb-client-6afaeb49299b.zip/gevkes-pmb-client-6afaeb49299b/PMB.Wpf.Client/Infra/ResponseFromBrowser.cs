﻿namespace PMB.Wpf.Client.Infra
{
    public class ResponseFromBrowser
    {
        public ResponseStatusStake StatusStake { get; set; }
        
        public string BrowserName { get; set; }
    }
}