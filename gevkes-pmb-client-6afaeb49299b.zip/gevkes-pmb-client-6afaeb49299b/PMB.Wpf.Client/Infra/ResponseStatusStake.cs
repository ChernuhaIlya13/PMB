﻿namespace PMB.Wpf.Client.Infra
{
    public enum ResponseStatusStake
    {
        NotFoundStake,
        FailedSetStakeSum,
        Success
    }
}