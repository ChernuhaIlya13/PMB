﻿namespace PMB.Wpf.Client.Infra
{
    public enum BrowserNumber
    {
        FirstBrowser,
        SecondBrowser
    }
}