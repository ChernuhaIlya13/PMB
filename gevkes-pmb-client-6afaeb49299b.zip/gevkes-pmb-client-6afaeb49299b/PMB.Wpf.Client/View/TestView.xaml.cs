﻿using System.Windows;

namespace PMB.Wpf.Client.View;

public partial class TestView : Window
{
    public TestView()
    {
        InitializeComponent();
    }
}