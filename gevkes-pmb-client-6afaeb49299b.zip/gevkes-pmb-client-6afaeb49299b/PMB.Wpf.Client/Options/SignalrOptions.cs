﻿namespace PMB.Wpf.Client.Options
{
    public class SignalrOptions
    {
        public string HubUrl { get; set; }
    }
}