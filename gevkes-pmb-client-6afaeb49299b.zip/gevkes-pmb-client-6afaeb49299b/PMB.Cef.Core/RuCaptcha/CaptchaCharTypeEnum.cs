﻿namespace PMB.Cef.Core.RuCaptcha
{
    public enum CaptchaCharTypeEnum
    {
        Default,
        OnlyDigits,
        OnlyLetter,
        OnlyDigitsOrOnlyLetter,
    }
}
