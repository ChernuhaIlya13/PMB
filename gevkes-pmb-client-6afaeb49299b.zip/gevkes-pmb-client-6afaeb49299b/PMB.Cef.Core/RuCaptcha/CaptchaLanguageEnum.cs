﻿namespace PMB.Cef.Core.RuCaptcha
{
    public enum CaptchaLanguageEnum
    {
        Default,
        Russian,
        English,
    }
}
