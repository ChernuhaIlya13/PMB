﻿namespace PMB.Cef.Core.FakeConfig
{
    public enum BrowserType
    {
        Chrome = 1,
        Opera = 2,
        Safari = 3,
        Yandex = 4,
    }
}