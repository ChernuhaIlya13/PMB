﻿namespace PMB.Cef.Core.JsProxy
{
    public record MatchDataParam(string eventId = null);
}