﻿namespace PMB.Domain.BrowserModels;

public enum StatusParseBalance
{
    Success,
    NotEnoughMoney,
    FailedParseBalance,
}