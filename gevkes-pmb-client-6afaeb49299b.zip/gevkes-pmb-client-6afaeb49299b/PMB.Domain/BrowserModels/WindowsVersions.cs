﻿namespace PMB.Cef.Core.FakeConfig
{
    public enum WindowsVersion
    {
        Win7,
        Win8,
        Win81,
        Win10,
        Win11
    }
}