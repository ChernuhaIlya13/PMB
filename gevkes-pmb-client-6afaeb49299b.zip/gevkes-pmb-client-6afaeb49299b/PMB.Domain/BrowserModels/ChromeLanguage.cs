﻿namespace PMB.Cef.Core.FakeConfig
{
    public enum ChromeLanguage
    {
        Ru,
        EnUsa,
        EnGb,
        Sw,
        De,
        Fr,
        It,
        Kz,
    }
}