﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMB.Domain.BrowserModels
{
    public class TimezoneSetting
    {
        public bool HideTimezone { get; set; }

        public string CustomTimezone { get; set; }

        public string StringPresent { get; set; }
    }
}
