﻿namespace PMB.Domain.BrowserModels
{
    public enum Schemes
    {
        Http,
        Https,
        Socks4,
        Socks5
    }
}