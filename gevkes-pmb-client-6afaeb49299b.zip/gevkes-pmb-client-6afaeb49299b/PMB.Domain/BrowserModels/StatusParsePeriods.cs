﻿namespace PMB.Domain.BrowserModels;

public enum StatusParsePeriods
{
    Success,
    FailedParsePeriods,
    UnknownFail,
    None
}