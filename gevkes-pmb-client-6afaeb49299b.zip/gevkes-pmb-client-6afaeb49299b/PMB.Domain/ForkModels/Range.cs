﻿namespace PMB.Domain.ForkModels
{
        public class Range { 
            public int Start { get; set; }
            public int Finish { get; set; }
        }
}