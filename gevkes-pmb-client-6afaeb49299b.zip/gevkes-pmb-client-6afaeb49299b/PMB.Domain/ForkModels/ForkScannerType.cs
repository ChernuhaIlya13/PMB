﻿namespace PMB.Domain.ForkModels
{
    public enum ForkScannerType
    {
        Positivebet,
        AllBestBets,
        None
    }
}