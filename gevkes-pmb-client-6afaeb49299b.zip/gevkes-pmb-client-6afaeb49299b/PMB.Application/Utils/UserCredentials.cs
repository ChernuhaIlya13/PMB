﻿namespace PMB.Application.Utils
{
    public static class UserCredentials
    {
        public static string JwtToken { get; set; } = "";

        public static string UserKey { get; set; } = "";
    }
}