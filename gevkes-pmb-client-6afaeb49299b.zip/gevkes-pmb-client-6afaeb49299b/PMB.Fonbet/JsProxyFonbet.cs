using PMB.Cef.Core;
using PMB.Cef.Core.JsProxy;

namespace PMB.Fonbet;

public class JsProxyFonbet : JsProxyBase
{
    public JsProxyFonbet(string captcha, BotBrowser browser) : base(captcha, browser)
    {
    }
}