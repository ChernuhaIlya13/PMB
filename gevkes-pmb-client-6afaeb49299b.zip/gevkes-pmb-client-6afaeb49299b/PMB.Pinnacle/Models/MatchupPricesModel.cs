﻿namespace PMB.Pinnacle.Models
{
    public record MatchupPricesModel(int Matchup, PriceInfo Price);
}