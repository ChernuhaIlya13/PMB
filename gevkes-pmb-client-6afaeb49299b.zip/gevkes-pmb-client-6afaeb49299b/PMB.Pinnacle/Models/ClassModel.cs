﻿using System;

namespace PMB.Pinnacle.Models;

public class ClassModel
{
    public string Name { get; set; }
    
    public Decimal Price { get; set; }
}