﻿namespace PMB.Pinnacle.Models;

public class StraightQuoteModel
{
    public string OddsFormat { get; set; }
    
    public SelectionModel[] Selections { get; set; }
}